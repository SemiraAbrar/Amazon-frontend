import CarouselEffect from "./Components/Carousel/Carousel";
// import "bootstrap/dist/css/bootstrap.min.css";
import "./App.css";
import Header from "./Components/Header/Header";
import Category from "./Components/Category/Category";
import Category2 from "./Components/Category2/Category2";
import Routing from "./Router";
import { ThemeProvider } from "./Example/ContextProvider";
import ComponentA from "./Example/ComponentA";
import ComponentB from "./Example/ComponentB";

function App() {
  return (
     <Routing/> 
    // <ThemeProvider>
    //   <ComponentA />

    //   <ComponentB />
    // </ThemeProvider>
  );
  {
    /* <Routing/> */
  }
  {
    /* <Header />
      <CarouselEffect />
      <Category />
      <Category2 /> */
  }
}

export default App;
