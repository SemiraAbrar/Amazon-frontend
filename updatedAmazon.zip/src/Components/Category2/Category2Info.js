export const category2Info = [
  // {
  //   title: "jwelery",
  //   name: "Toys under $25",
  //   imgLink:
  //     "https://images-na.ssl-images-amazon.com/images/G/01/AmazonExports/Events/2023/EBF23/Fuji_Desktop_Single_image_EBF_2x_v3._SY608_CB573698005_.jpg",
  // },
  // {
  //   title: "Cosmetics",
  //   name: "Beauty steals under $25",
  //   imgLink:
  //     "https://images-na.ssl-images-amazon.com/images/G/01/AmazonExports/Events/2023/EBF23/Fuji_Desktop_Single_image_EBF_2x_v5._SY608_CB573698005_.jpg",
  // },
  // {
  //   title: "Electronics",
  //   name: "Get your game on",
  //   imgLink:
  //     "https://images-na.ssl-images-amazon.com/images/G/01/AmazonExports/Events/2024/Stores-Gaming/FinalGraphics/Fuji_Gaming_store_Dashboard_card_2x_EN._SY608_CB564799420_.jpg",
  // },
  // {
  //   title: "Home decor",
  //   name: "Home décor under $50",
  //   imgLink:
  //     "https://images-na.ssl-images-amazon.com/images/G/01/AmazonExports/Events/2023/EBF23/Fuji_Desktop_Single_image_EBF_2x_v6._SY608_CB573698005_.jpg",
  // },
  {
    title: "Mens Cotton Jacket",
    name: "men's clothing",
    imgLink: "https://fakestoreapi.com/img/71li-ujtlUL._AC_UX679_.jpg",
  },
  {
    name: "jewelery",
    title: "White Gold Plated Princess",
    imgLink: "https://fakestoreapi.com/img/71YAIFU48IL._AC_UL640_QL65_ML3_.jpg",
  },
  {
    name: "electronics",
    title:
      "WD 4TB Gaming Drive Works with Playstation 4 Portable External Hard Drive",
    imgLink: "https://fakestoreapi.com/img/61mtL65D4cL._AC_SX679_.jpg",
  },
  {
    name: "women's clothing",
    title: "DANVOUY Womens T Shirt Casual Cotton Short",
    imgLink: "https://fakestoreapi.com/img/61pHAEJ4NML._AC_UX679_.jpg",
  },
];