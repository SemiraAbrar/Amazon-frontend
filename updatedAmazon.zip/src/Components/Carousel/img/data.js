import img1 from './c2_.jpg';
import img2 from './ca_.jpg';
import img3 from './c3.jpg';
import img4 from './c4.jpg';
import img5 from "./c5.jpg";
export const img=[img1,img2,img3,img4,img5]