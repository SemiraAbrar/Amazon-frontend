import React from 'react'

function CurrencyFormat({amount}) {
  return (
    <div>{`$${amount} `}</div>
  )
}

export default CurrencyFormat