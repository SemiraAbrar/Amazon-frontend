import React from 'react'
import Layout from '../../Components/Layout/Layout'

function Orders() {
  return (
    <Layout>
      <div>Orders</div>
    </Layout>
  );
}

export default Orders