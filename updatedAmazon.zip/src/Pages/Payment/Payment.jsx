import React from 'react'
import classes from './Payment.module.css'
import Layout from '../../Components/Layout/Layout'
function Payment() {
  return (
    <Layout>
      <div>Payment</div>
    </Layout>
  );
}

export default Payment