import React from 'react'
import classes from './Signup.module.css'
function Signup() {
  return (
    <div>Signup</div>
  )
}

export default Signup